<template>
	<view class="tm-formGeneration">
		
	</view>
</template>

<script>
	export default {
		name:'tm-formGeneration',
		data() {
			return {
				formJson:[
					{
						"name":"input",
						"type":"text",
						"subName":"user",
						"title":"登录用户名",
						"suffix":"",
						"required":true,
					}
				]
			};
		}
	}
</script>

<style lang="scss">

</style>
